function Bn_act = calc_loopnoisebw(Hz, Ta)

% Calculate Bn_act
walias = pi/Ta;
wvec = 0:10000'*(walias/10000);
[magvec, ~] = bode(Hz,wvec);
magvec = magvec(:);
Bn_act = sum(magvec.^2)*mean(diff(wvec))/(2*pi*(magvec(1,1)^2));

end