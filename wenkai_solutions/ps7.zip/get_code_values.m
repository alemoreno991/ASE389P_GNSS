function code_epl = get_code_values(tauj, tstart, teml, code_val, code_t, data_sw)

if nargin < 6
    data_sw = false;
end


% Bias code timestamps by tstart. Then, circularly shift taking mod with
% respect to 1 ms. Sort to make sure interpolation works correctly. At the
% end of the day, all time values should reside within 0 and 1 ms.

% |-----------------------------------------|               Base code.
%  0                                     1ms
%
%                                           |  use the value here to paste into sorted code
%                                           v
%            |------------------------------.----------|    Time biased code.
%             tstart                         tstart+1ms
%
%
%
% .---------||------------------------------.               Modded, sorted code.
% 0   ts+1ms  tstart                       1ms

% Get all proper times.
bias_code_t = code_t + mod(tstart, 1e-3);
mod_code_t  = mod(bias_code_t, 1e-3);

early_tau   = mod(tauj-teml/2, 1e-3);  % Advancing code = delaying  tauj sample.
prompt_tau  = mod(tauj       , 1e-3);
late_tau    = mod(tauj+teml/2, 1e-3);  % Delaying  code = advancing tauj sample.

tau_vec = [early_tau; prompt_tau; late_tau];

% Sort. Apply data bit switch if necessary.
[sort_code_t, idx_sort] = sort(mod_code_t);
if data_sw
    idx_sw = bias_code_t>1e-3;
    code_val(idx_sw) = -code_val(idx_sw);
end

sort_code_val = code_val(idx_sort);

% Augment such that full [0, 1 ms] interval is filled.
if bias_code_t(end) < 1e-3
    code_val   (end+1) = code_val(1);
    bias_code_t(end+1) = 1e-3;
end
paste_val = interp1(bias_code_t, code_val, 1e-3);
paste_val = roundpm1(paste_val);

if sort_code_t(1) ~= 0
    sort_code_val = [paste_val sort_code_val];
    sort_code_t   = [0         sort_code_t  ];
end

if sort_code_t(end) ~= 1e-3
    sort_code_val = [sort_code_val paste_val];
    sort_code_t   = [sort_code_t   1e-3     ];
end

% Interpolate and round values to +1/-1.
code_epl = interp1(sort_code_t, sort_code_val, tau_vec);
code_epl = roundpm1(code_epl);

end

% Round positive values to +1, negative values to -1. Helps avoid the
% approximation that comes from interpolating between a code timeseries.
function xr = roundpm1(x)

xr = sign(x);
xr(xr==0) = 1;

end