%% Load data.
clc, clear

addpath('acquire')
addpath('stats')

Toffset = 3;                    % Time from beginning to start taking samples.
Tfull   = 0.5;                  % Time interval of data to load (1 ms = 1 data chip).
Fs      = 40e6/7;               % Sampling frequency (Hz).
Ts      = 1/Fs;                 % Sampling period (s).
Noffset = floor(Fs*Toffset);    % Number of data samples to offset start.
N       = floor(Fs*Tfull);      % Number of data samples to load.
N       = N+8-(mod(N,8));       % Round to nearest 8.
nfft    = 2^9;                  % Size of FFT used in power spectrum estimation.
fIF     = 1.405396825396879e6;  % Intermediate frequency.

fid           = fopen('dfDataHead.bin','r','l');
[yhist,count] = binloadSamples(fid,N,'dual');
yhist         = yhist(:,1);
fclose(fid);

%% Coarse acquisition, other general parameters.
T       = 1/Fs;              % Sampling period.
Tc      = 1e-3/1023;         % Chipping period.
Taccum  = 1.0e-3;            % Accumulation interval. Should be multiple of chirping period.
Nk      = round(Taccum*Fs);  % Number of samples in accumulation interval.

first_k  =   0;              % First accumulation interval number.
n_accums =  30;              % Number of noncoherent summations.

doppler_max = 10e3;          % Doppler search bounds.
doppler_del = 1/(Taccum);    % Doppler search resolution. (Consistent with acquisition hypothesis stat calculations.)

fcL1 = 1575.42e6;

%% Determine test statistic.
statparam.C_N0dBHz     = 40;               % Not necessary to determine lambda0, only Pd.
statparam.N            = n_accums;         % Number of noncoherent accumulations.
statparam.PfaAcq       = 2e-6;             % Desired chance of false acquisition.
statparam.Ta           = Taccum;           % Time of accumulation.
statparam.fMax         = doppler_max;      % Maximum value of frequency.
statparam.nCodeOffsets = floor(1e-3*1/T);  % Number of code offsets to test.
statparam.ZMax         = 1000;             % Max value of test stat (sum of Sk^2).
statparam.delZ         = 0.1;              % Resolution of output PDFs.

[pZ_H0,pZ_H1,lambda0,Pd,ZVec] = performAcqHypothesisCalcs(statparam);
lambda0 = 1.2*lambda0;

%% Perform a coarse acquisition.
signal = yhist;

% Populate parameter structure.
acqparam.Fs       = Fs;                       % Sampling frequency.
acqparam.Fif      = fIF;                      % Intermediate frequency of signal.
acqparam.first_k  = first_k;                  % Accumulation interval number.
acqparam.n_accums = n_accums;                 % Number of accumulations to noncoherently sum.
acqparam.Taccum   = Taccum;                   % Accumulation interval.
acqparam.decision = lambda0;                  % Decision variable for acq/noacq.
acqparam.varIQ    = NaN;                      % Variance of IQ noise.

% Other params.
n_step = 1;
jk_search = 0:n_step:(1e-3/T)-1;
acqparam.doppler_search = -doppler_max:doppler_del:doppler_max;

%% Construct Sk matrix.

% Get varIQ.
acqparam.varIQ = getvarIQ(signal,acqparam);

% For each Gold code.
for txid = 14

    [found, doppler, start_time, CN0, Sk2] = acquire_gps(signal, txid, acqparam, 'fft');

    % Text output.
    if found
        fprintf('---------------------------------\n')
        fprintf('Found TXID %d!\n'                  , txid)
        fprintf('Doppler Frequency: %5.4g Hz\n'     , doppler)
        fprintf('Start Time       : %5.4g µs\n'     , start_time*1e6)
        fprintf('C/N0             : %5.4g dB-Hz\n'  , CN0)
    end

    % Save Doppler for TXID 14.
    if txid == 14
        txid14_doppler = doppler;
        txid14_sk2     = Sk2;
    end

end

fprintf('---------------------------------\n')

%% Fine-tune acquisition.
fprintf('Fine-tuning Doppler estimate of TXID 14...\n')

acqparam.Taccum    = 10e-3;
acqparam.n_accums  = 4;
doppler_del_coarse = doppler_del;
doppler_del_fine   = 10;
acqparam.doppler_search = txid14_doppler + (-doppler_del_coarse:doppler_del_fine:doppler_del_coarse);

[found, txid14_doppler, txid14_tstart, CN0, ~] = acquire_gps(signal, 14, acqparam, 'fft', 1);
figure(1)
set(gcf, 'Units', 'normalized', 'Position', [0.1997 0.5452 0.2998 0.3500])
fprintf('Refined Doppler estimate: %5.4g Hz.\n', txid14_doppler)

%% Initialize.
% |Sk|^2 running average buffer.
buffer_length = 100;
Sk2buffer = max(txid14_sk2(:)) * acqparam.varIQ * ones(1, buffer_length); % TODO: Maybe don't make it so I have to multiply by varIQ...

% Phase loop filter parameters.
Bn_target = 20;
loop_order = 3;
[Ad, Bd, Cd, Dd, Bn_act] = configureLoopFilter(Bn_target, Taccum, loop_order);
plls.Ad = Ad;
plls.Bd = Bd;
plls.Cd = Cd;
plls.Dd = Dd;

% Initial phase loop filter state.
if loop_order > 1
    [v,d] = eig(Ad);
    ind = find(diag(d)==1,1);
    xk = v(:,ind);
    xk = 2*pi*txid14_doppler/dot(Cd,xk) * xk;
    xkp1 = xk;
else
    xk   = zeros(0,1);
    xkp1 = zeros(0,1);
end

% Delay loop parameters.
Sm             = -1; % TODO: Make this change on low/high side mixing.
dlls.Bn_target = 20;
dlls.IsqQsqAvg = mean(Sk2buffer);
dlls.sigmaIQ   = sqrt(acqparam.varIQ);
dlls.vp        = 0;
dlls.Tc        = Tc;
dlls.Ip        = 0;
dlls.Qp        = 0;
dlls.Ie        = 0;
dlls.Qe        = 0;
dlls.Il        = 0;
dlls.Ql        = 0;

% Correlator parameters and data.
corrparam.Fs      = Fs;             % sampling frequency, Hz
corrparam.Fif     = fIF;            % intermediate frequency, Hz
corrparam.teml    = 0.5*Tc;         % delay between early and late taps on code, sec
corrparam.txid    = 14;             % TXID/PRN number
corrparam.Taccum  = Taccum;         % accumulation period
corrparam.Tc      = Tc;             % chipping period (1 ms/1023 chips)
corrparam.init_th = 0;              % initial phase estimate
corrparam.init_ts = txid14_tstart;  % initial code start time estimate
corrdata          = [];             % Note the correlator data will initialize in the data.
corrdata_bitsw = corrdata;

% Initial estimate of phase, code start time rates.
vcode_k  = 0;
vtheta_k = txid14_doppler*2*pi;

% Trigger for Taccum intervals.
% TODO: Integrate this into the correlator data? Maybe. Maybe not.
elap_accums_last = 0;

% % Fake signal.
% FLAG_USE_FAKE = false;
% 
% if FLAG_USE_FAKE
% 
%     Tfull   = 0.2;
%     Tswitch = 0.15;
%     pad_l = round(Tswitch/Ts);
% 
%     taujv = Ts * (0:round(Tfull/Ts));
% 
%     slope  = 2*pi;
%     th_tru = [slope*taujv(1:pad_l).*ones(1,pad_l), slope*taujv(pad_l)*ones(1, length(taujv)-pad_l)];
% 
%     signal = cos(2*pi*fIF*taujv+th_tru); % signal, sqrt(W)
%     corrparam.init_th = 0;          % initial phase estimate
%     corrparam.init_ts = 0;          % initial code start time estimate
%     Sk2buffer = [0 0];
% 
%     xk   = zeros(size(xk));
%     xkp1 = xk;
% 
% end

% Recorders.
record.phase_est  = nan([1 length(signal)]);
record.tstart_est = nan([1 length(signal)]);
record.vtheta_k   = nan([1 length(signal)]);
record.vcode_k    = nan([1 length(signal)]);
record.Sk2        = nan([1 length(signal)]);
record.Skepl      = nan([3 length(signal)]);

% Clear plots.
figure(2), clf
set(gcf, 'Units', 'normalized', 'Position', [0.5 0.8 0.5 0.35])

figure(3), clf
set(gcf, 'Units', 'normalized', 'Position', [0.5 0.1235 0.5 0.35])

figure(4), clf
set(gcf, 'Units', 'normalized', 'Position', [0 0.1235 0.4995 0.350])

%% Loop.
tic
% For every value of the signal...
for j = 1:length(signal)

    plot_this_loop = false;

    if mod(j,floor(length(signal)/100))==0

        if ~exist('pt_waitbar','var')
            pt_waitbar = waitbar(0);
        end
        elap_t = toc;
        tic
        frac_done = (j-1)/length(signal);
        % fprintf('%.1f', frac_done*100)
        msg = sprintf('Estimated Total Time: %.1f s', elap_t*100);
        waitbar(frac_done, pt_waitbar, msg);

    end

    xj = signal(j);

    % Pass into correlator.
    [Skepl      , corrdata      ] = correlator(xj, j, vtheta_k, vcode_k, corrdata      , corrparam);
    [Skepl_bitsw, corrdata_bitsw] = correlator(xj, j, vtheta_k, vcode_k, corrdata_bitsw, corrparam, true);

    if abs(Skepl_bitsw) > abs(Skepl)
        
        disp(mag2db(abs(Skepl)))
        disp(mag2db(abs(Skepl_bitsw)))
        Skepl = Skepl_bitsw;

    end

    % Detect Taccum intervals. If the correlator's n_accums has
    % incremented, that indicates we have a fresh value of Sk and should
    % update the code/phase rate estimates.
    if corrdata.elap_accums ~= elap_accums_last

        fprintf('----------------------\n')

        disp(mag2db(abs(Skepl)))

        % Update the moving window average of |Sk|^2.
        Sk2buffer(2:end) = Sk2buffer(1:end-1);
        Sk2buffer(1)     = abs(Skepl(2)).^2;

        % Carrier loop filter.
        plls.Ip = real(Skepl(2));
        plls.Qp = imag(Skepl(2));
        plls.xk = xkp1;
        [xkp1, vtheta_k] = updatePll(plls);

        % Code loop filter, applying Sm/wc gain.
        dlls.vp = vtheta_k * Sm/(2*pi*fcL1);
        dlls.IsqQsqAvg = mean(Sk2buffer);

        dlls.Ie = real(Skepl(1)); dlls.Qe = imag(Skepl(1));
        dlls.Ip = real(Skepl(2)); dlls.Qp = imag(Skepl(2));
        dlls.Il = real(Skepl(3)); dlls.Ql = imag(Skepl(3));

        vcode_k = updateDll(dlls);

        plot_this_loop = true;

    end

    % Remember elapsed accumulations for triggering.
    elap_accums_last = corrdata.elap_accums;

    % Record data.
    record.elapsed_t (j) = (j-1)*Ts;
    record.phase_est (j) = corrdata.phase_est;
    record.tstart_est(j) = corrdata.tstart_est;
    record.vtheta_k  (j) = vtheta_k;
    record.vcode_k   (j) = vcode_k;
    record.Skepl   (:,j) = Skepl;

    % Plot.
    if plot_this_loop
        record.elapsed_t = record.elapsed_t;

        % Magnitude of accumulations.
        figure(2), clf

        subplot(121)
        plot(record.elapsed_t(1:j), 1/2*mag2db(abs(record.Skepl(2,1:j)).^2))
        xlabel('Time (s)')
        ylabel('|Sk|^2 (dBW)')
        xlim([0 Tfull])
        hold on, grid on

        subplot(122)
        hold on, grid on
        scatter3(real(record.Skepl(2,1:j)), imag(record.Skepl(2,1:j)), record.elapsed_t(1:j), '.')
        xlabel('Re\{Sk\}')
        ylabel('Im\{Sk\}')
        zlabel('Time (s)')
        view(10, 20)
%         axis equal

        % Phase tracking.
        figure(3), clf

        subplot(211)
        hold on, grid on
        if exist('th_tru','var')
            plot(record.elapsed_t(1:j), th_tru(1:j))
        end
        plot(record.elapsed_t(1:j), record.phase_est(1:j))
        xlabel('Time (s)')
        ylabel('Phase Estimate (rad)')
        xlim([0 Tfull])

        subplot(212)
        hold on, grid on
        plot(record.elapsed_t(1:j), record.vtheta_k(1:j)/(2*pi))
        xlabel('Time (s)')
        ylabel('Doppler Estimate (Hz)')
        xlim([0 Tfull])

        % Code tracking.
        figure(4), clf

        subplot(211)
        hold on, grid on
        plot(record.elapsed_t(1:j), record.tstart_est(1:j))
        xlabel('Time (s)')
        ylabel('Start Time Estimate (sec)')
        xlim([0 Tfull])

        subplot(212)
        hold on, grid on
        plot(record.elapsed_t(1:j), record.vcode_k(1:j))
        xlabel('Time (s)')
        ylabel('Start Time Rate Estimate (sec/sec)')
        xlim([0 Tfull])
    end

end

close(pt_waitbar)

