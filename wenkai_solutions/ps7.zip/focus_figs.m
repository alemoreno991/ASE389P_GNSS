function focus_figs(fignum)

for i = fignum
    figure(i)
end