function [found, doppler, start_time, CN0, Sk2] = acquire_gps(signal, txid, param, method, fignum)

if nargin < 4
    method = 'fft';
else
    method = lower(method);
end

if nargin < 5
    fignum = 0;
end

if ~isfield(param, 'Fif')
    param.Fif = 0;
end

% All needs from parameters structure.
Fs             = param.Fs;              % Sampling frequency.
Fif            = param.Fif;             % Intermediate frequency of signal.
varIQ          = param.varIQ;           % Variance of IQ noise.
Taccum         = param.Taccum;          % Accumulation interval.
doppler_search = param.doppler_search;  % Doppler search space.
first_k        = param.first_k;         % First accumulation interval to examine.
n_accums       = param.n_accums;        % Number of accumulation intervals over which to noncoherently sum.
decision       = param.decision;        % Decision variable for test statistic.

% Calculated parameters.
Ts = 1/Fs;                              % Sampling period.
Nk = round(Taccum*Fs);                  % Number of samples in accumulation interval.

codeLength = 1023;                      % Number of chips in spreading code.
Tc = 1e-3/codeLength;                   % Chipping frequency.
n_step = 1;                             % Index delay resolution.
jk_search = 0:n_step:(1e-3/Ts)-1;       % Start time search space.
% nfft = 2^nextpow2(Nk);                  % Number of FFT bins to use.
nfft = Nk;

tic

% Construct Sk matrix.
Sk2 = nan(length(jk_search), length(doppler_search), n_accums);
for k = first_k:(first_k+n_accums-1)

    j_start = Nk*k+1;                       % Starting index of accumulation interval.
    j = j_start:(j_start+Nk-1);             % Indices over accumulation interval.
    tau_j = (j-1)'*Ts;                      % Time over accumulation interval.

    signal_j   = signal(j);

    % Construct oversampled spreading code assuming 0 start time.
    curr_code = txid2gc(txid);
    cj_noshift = oversampleSpreadingCode(curr_code,Ts/Tc,0,Nk,codeLength);

    if strcmp(method, 'fft')

        % Make signal and Doppler matrices.
        signal_mat = repmat(signal_j,1,length(doppler_search));

        % Make timeseries multiplied by Doppler matrix.
        doppler_mat = exp(-1j*2*pi*tau_j*(Fif + doppler_search));
        signal_dop = signal_mat .* doppler_mat;

        % Take DFT of spreading code and timeseries*Doppler.
        signal_dop_F = fft(signal_dop, nfft, 1);
        cj_noshift_F = fft(cj_noshift, nfft, 1);

        % Perform correlation via multiplication in frequency domain.
        Ski = ifft(signal_dop_F .* conj(cj_noshift_F), nfft ,1);
        
    else
        
        % Make signal and Doppler matrices.
        signal_mat = repmat(signal_j,1,length(jk_search));
        doppler_mat = exp(-1j*2*pi*tau_j*(Fif + doppler_search));
        
        % Shift to get all start times.
        cj_shifted = nan(Nk, length(jk_search));
        cj_shifted(:,1) = cj_noshift;

        % Construct spreading code start time.
        for jk = 2:length(jk_search)

            % Construct shifted code vector.
            cj_shifted(:,jk) = circshift(cj_shifted(:,jk-1), 1);

        end
        signal_code = signal_mat .* cj_shifted;
        Ski = signal_code' * doppler_mat;

    end

    if ~isnan(varIQ)
        % Add non-coherently. Normalize with varIQ for test statistic.
        Sk2i = abs(Ski).^2/varIQ;
    else
        % If varIQ was passed in as NaN, then use 1 to pass raw Sk2 values
        % out.
        Sk2i = abs(Ski).^2;
    end

    % Record Sk2s.
    Sk2(:,:,k-first_k+1) = Sk2i(1:length(jk_search),:,:);

end

% Get test statistic.
Z = sum(Sk2, 3);

% Get results.
[mesh_doppler, mesh_tauj] = meshgrid(doppler_search, (j_start-1+(1:size(Z,1)))*1/Fs);

if max(Z(:)) > decision && ~isnan(varIQ)
    found      = true;
    idx_max    = find(Z == max(Z(:)),1);
    doppler    = mesh_doppler(idx_max);
    start_time = mesh_tauj   (idx_max);
    start_time = mod(start_time, 1e-3);
    CN0        = 10*log10( (max(Sk2(:))-2)/(2*Taccum) );
else
    found      = false;
    doppler    = NaN;
    start_time = NaN;
    CN0        = NaN;
end

% Plot.
if fignum > 0
    figure(fignum), clf
    s = surf(mesh_doppler, mesh_tauj, Z);
    s.EdgeColor = 'none';
    xlim([min(mesh_doppler(:)) max(mesh_doppler(:))     ])
    ylim([min(mesh_tauj   (:)) min(mesh_tauj   (:))+1e-3])
%     ylim([min(mesh_tauj   (:)) max(mesh_tauj   (:))])
    xlabel('Doppler (Hz)')
    ylabel('Delay (s)')
    zlabel('|S_k|')
    title(sprintf('Satellite Acquisition Search, TXID %d', txid))
end

end