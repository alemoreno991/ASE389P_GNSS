% Check that a0 initialization is of the correct form.
function checkInputLfsr(n, a0Vec)
if ~isequal(n, length(a0Vec))
    error('Error. Input a0Vec must be length n.')
end
if mean(ismember(a0Vec,[0 1])) ~= 1
    error('Error. Input a0Vec must be 1/0-valued linear sequence.')
end
end