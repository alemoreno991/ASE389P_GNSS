function varIQ = getvarIQ(signal, params)

% Make sure we're calling acquire_gps without a real varIQ.
params.varIQ = NaN;

[~, ~, ~, ~, Sk34sq] = acquire_gps(signal, 34, params, 'fft');
Z34 = sum(Sk34sq, 3);
varIQ = mean(Z34(:))/(2*params.n_accums);

end