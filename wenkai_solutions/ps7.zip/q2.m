%% Load data.
clc, clear

addpath('acquire')
addpath('stats')

Toffset = 3;                    % Time from beginning to start taking samples.
Tfull   = 50;                    % Time interval of data to load (1 ms = 1 data chip).
Fs      = 40e6/7;               % Sampling frequency (Hz).
Ts      = 1/Fs;                 % Sampling period (s).
Noffset = floor(Fs*Toffset);    % Number of data samples to offset start.
N       = floor(Fs*Tfull);      % Number of data samples to load.
N       = N+8-(mod(N,8));       % Round to nearest 8.
nfft    = 2^9;                  % Size of FFT used in power spectrum estimation.
fIF     = 1.405396825396879e6;  % Intermediate frequency.

fid           = fopen('dfDataHead.bin','r','l');
[yhist,count] = binloadSamples(fid,N,'dual');
yhist         = yhist(:,1);
fclose(fid);

%% Coarse acquisition, other general parameters.
T       = 1/Fs;              % Sampling period.
Tc      = 1e-3/1023;         % Chipping period.
Taccum  = 4.0e-3;            % Accumulation interval. Should be multiple of chirping period.
Nk      = round(Taccum*Fs);  % Number of samples in accumulation interval.

first_k  =   0;              % First accumulation interval number.
n_accums =  50;              % Number of noncoherent summations.

doppler_max = 10e3;          % Doppler search bounds.
doppler_del = 0.5/(Taccum);    % Doppler search resolution.
doppler_search = -doppler_max:doppler_del:doppler_max;

fcL1 = 1575.42e6;

%% Determine test statistic.
statparam.C_N0dBHz     = 40;                     % Not necessary to determine lambda0, only Pd.
statparam.N            = n_accums;               % Number of noncoherent accumulations.
statparam.PfaAcq       = 2e-6;                   % Desired chance of false acquisition.
statparam.Ta           = Taccum;                 % Time of accumulation.
statparam.fMax         = doppler_max;            % Maximum value of frequency.
statparam.nFreqOffsets = length(doppler_search); % Number of doppler frequncies to test.
statparam.nCodeOffsets = floor(1e-3*1/T);        % Number of code offsets to test.
statparam.ZMax         = 1000;                   % Max value of test stat (sum of Sk^2).
statparam.delZ         = 0.1;                    % Resolution of output PDFs.

[pZ_H0,pZ_H1,lambda0,Pd,ZVec] = performAcqHypothesisCalcs(statparam);
lambda0 = 1.2*lambda0;

%% Perform a coarse acquisition.
signal = yhist;

% Populate parameter structure.
acqparam.Fs       = Fs;                       % Sampling frequency.
acqparam.Fif      = fIF;                      % Intermediate frequency of signal.
acqparam.first_k  = first_k;                  % Accumulation interval number.
acqparam.n_accums = n_accums;                 % Number of accumulations to noncoherently sum.
acqparam.Taccum   = Taccum;                   % Accumulation interval.
acqparam.decision = lambda0;                  % Decision variable for acq/noacq.
acqparam.varIQ    = NaN;                      % Variance of IQ noise.

% Other params.
n_step = 1;
jk_search = 0:n_step:(1e-3/T)-1;
acqparam.doppler_search = doppler_search;

%% Construct Sk matrix.
target_txid = 5;

% Get varIQ.
acqparam.varIQ = getvarIQ(signal,acqparam);

% For each Gold code.
for txid = target_txid

    [found, doppler, start_time, CN0, Sk2] = acquire_gps(signal, txid, acqparam, 'fft', 1);

    % Text output.
    fprintf('---------------------------------\n')
    if found
        fprintf('Found TXID %d!\n'                  , txid)
        fprintf('Doppler Frequency: %5.4g Hz\n'     , doppler)
        fprintf('Start Time       : %5.4g µs\n'     , start_time*1e6)
        fprintf('C/N0             : %5.4g dB-Hz\n'  , CN0)
    else
        fprintf('TXID %d not found.\n', txid)
        fprintf('---------------------------------\n')
        return
    end

    % Save Doppler for target TXID.
    if txid == target_txid
        target_doppler = doppler;
        target_sk2     = Sk2;
    end

end

fprintf('---------------------------------\n')

%% Fine-tune acquisition.
fprintf('Fine-tuning Doppler estimate of TXID %d...\n', target_txid)

acqparam.Taccum    = 10e-3;
acqparam.n_accums  = 4;
doppler_del_coarse = doppler_del;
doppler_del_fine   = 10;
acqparam.doppler_search = target_doppler + (-doppler_del_coarse:doppler_del_fine:doppler_del_coarse);

[found, target_doppler, target_tstart, CN0, ~] = acquire_gps(signal, target_txid, acqparam, 'fft', 1);
figure(1)
set(gcf, 'Units', 'normalized', 'Position', [0.1997 0.5452 0.2998 0.3500])
fprintf('Refined Doppler estimate: %5.4g Hz.\n', target_doppler)

%% Initialize.
% |Sk|^2 running average buffer.
buffer_length = 100;
Sk2buffer = max(target_sk2(:)) * acqparam.varIQ * ones(1, buffer_length); % TODO: Maybe don't make it so I have to multiply by varIQ...

% Phase loop filter parameters.
Bn_target = 10;
loop_order = 3;
[Ad, Bd, Cd, Dd, Bn_act] = configureLoopFilter(Bn_target, Taccum, loop_order);
pll.Ad = Ad;
pll.Bd = Bd;
pll.Cd = Cd;
pll.Dd = Dd;

% Initial phase loop filter state.
if loop_order > 1
    [v,d] = eig(Ad);
    ind = find(diag(d)==1,1);
    xk = v(:,ind);
    xk = 2*pi*target_doppler/dot(Cd,xk) * xk;
    xkp1 = xk;
else
    xk   = zeros(0,1);
    xkp1 = zeros(0,1);
end

% Delay loop parameters.
Sm            = -1; % TODO: Make this change on low/high side mixing. FIX THIS
dll.Bn_target =  1;
dll.IsqQsqAvg = mean(Sk2buffer);
dll.sigmaIQ   = sqrt(acqparam.varIQ);
dll.vp        = 0;
dll.Tc        = Tc;
dll.Ip = 0; dll.Qp = 0;
dll.Ie = 0; dll.Qe = 0;
dll.Il = 0; dll.Ql = 0;

% Correlator parameters and data.
corrparam.Fs      = Fs;             % sampling frequency, Hz
corrparam.Fif     = fIF;            % intermediate frequency, Hz
corrparam.teml    = 0.5*Tc;         % delay between early and late taps on code, sec
corrparam.txid    = target_txid;    % TXID/PRN number
corrparam.Taccum  = Taccum;         % accumulation period
corrparam.Tc      = Tc;             % chipping period (1 ms/1023 chips)
corrparam.init_th = 0;              % initial phase estimate
corrparam.init_ts = target_tstart;  % initial code start time estimate
corrdata          = [];             % Note the correlator data will initialize in the data.
corrdata_bitsw = corrdata;

% Initial estimate of phase, code start time rates.
vcode_k  = 0;
vtheta_k = target_doppler*2*pi;

% Trigger for Taccum intervals.
% TODO: Integrate this into the correlator data? Maybe. Maybe not.
elap_accums_last = 0;

% Recorders.
record.phase_est  = nan([1 length(signal)]);
record.tstart_est = nan([1 length(signal)]);
record.vtheta_k   = nan([1 length(signal)]);
record.vcode_k    = nan([1 length(signal)]);
record.Sk2        = nan([1 length(signal)]);
record.Skepl      = nan([3 length(signal)]);

% CLEANUP ZONE YAYAYA
total_accums = floor(Tfull/Taccum);
time_vec = (1:length(signal))*Ts;

% Clear plots.
figure(2), clf
set(gcf, 'Units', 'normalized', 'Position', [0.5 0.8 0.5 0.35])

figure(3), clf
set(gcf, 'Units', 'normalized', 'Position', [0.5 0.1235 0.5 0.35])

figure(4), clf
set(gcf, 'Units', 'normalized', 'Position', [0 0.1235 0.4995 0.350])

%% Loop.
tic

Nfull = length(signal);

% Loop over accumulation intervals
for i_accum = 0:total_accums-1

    plot_this_loop = false;

    % Plot every N Ta.
%     if(mod(i_accum, total_accums-1)==0) || i_accum==total_accums-1
    if i_accum==total_accums-1
        plot_this_loop = true;
    end

    % Form j vector.
    j    = 1+ceil(i_accum*Taccum*Fs):1:round(min((1+i_accum)*Taccum*Fs, Nfull));
    tauj = time_vec(j);
    xj   = signal(j)';

    % Pass into correlator.
    [Skepl      , corrdata      ] = correlator(tauj, xj, vtheta_k, vcode_k, corrdata      , corrparam);
    [Skepl_bitsw, corrdata_bitsw] = correlator(tauj, xj, vtheta_k, vcode_k, corrdata_bitsw, corrparam, true);

    if abs(Skepl_bitsw(2)) > abs(Skepl(2))
        Skepl = Skepl_bitsw;
    end
    
    % Update the moving window average of |Sk|^2.
    Sk2buffer(2:end) = Sk2buffer(1:end-1);
    Sk2buffer(1)     = abs(Skepl(2)).^2;

    % Carrier loop filter.
    pll.Ip = real(Skepl(2));
    pll.Qp = imag(Skepl(2));
    pll.xk = xkp1;
    [xkp1, vtheta_k] = updatePll(pll);

    % Code loop filter, applying Sm/wc gain.
    dll.vp = -vtheta_k * Sm/(2*pi*fcL1);
    dll.IsqQsqAvg = mean(Sk2buffer);

    dll.Ie = real(Skepl(1)); dll.Qe = imag(Skepl(1));
    dll.Ip = real(Skepl(2)); dll.Qp = imag(Skepl(2));
    dll.Il = real(Skepl(3)); dll.Ql = imag(Skepl(3));

    vcode_k = updateDll(dll);

    % Record data.
    record.elapsed_t (j) = (j-1)*Ts;
    record.phase_est (j) = corrdata.phase_est;
    record.tstart_est(j) = corrdata.tstart_est;
    record.vtheta_k  (j) = vtheta_k;
    record.vcode_k   (j) = vcode_k;

    record.Skepl(:,i_accum+1) = Skepl;

    % Plot.
    if plot_this_loop

        % Magnitude of accumulations.
        figure(2), clf

        subplot(121)
        hold on, grid on
        plot(Taccum*(0:i_accum), 1/2*mag2db(abs(record.Skepl(2, 1:(i_accum+1))).^2))
        plot(Taccum*(0:i_accum), 1/2*mag2db(abs(record.Skepl([1 3], 1:(i_accum+1))).^2), ':')
        xlabel('Time (s)')
        ylabel('|Sk|^2 (dBW)')
        legend('Prompt', 'Early', 'Late', 'Location', 'southeast')
        xlim([0 Tfull])
        hold on, grid on

        subplot(122)
        hold on, grid on
        scatter3(real(record.Skepl(2, 1:(i_accum+1))), imag(record.Skepl(2, 1:(i_accum+1))), Taccum*(0:i_accum), '.')
        xlabel('Re\{Sk\}')
        ylabel('Im\{Sk\}')
        zlabel('Time (s)')
        view(10, 20)

        % Phase tracking.
        figure(3), clf

        subplot(211)
        hold on, grid on
        plot(record.elapsed_t(1:j(end)), unwrap(record.phase_est(1:j(end))))
        ylabel('Phase Estimate (rad)')
        xlim([0 Tfull])

        subplot(212)
        hold on, grid on
        plot(record.elapsed_t(1:j(end)), record.vtheta_k(1:j(end))/(2*pi))
        xlabel('Time (s)')
        ylabel('Doppler Estimate (Hz)')
        xlim([0 Tfull])

        % Code tracking.
        figure(4), clf

        subplot(211)
        hold on, grid on
        plot(record.elapsed_t(1:j(end)), 1e3*record.tstart_est(1:j(end)))
        ylabel('Start Time Estimate (msec)')
        xlim([0 Tfull])

        subplot(212)
        hold on, grid on
        plot(record.elapsed_t(1:j(end)), 1e3*record.vcode_k(1:j(end)))
        xlabel('Time (s)')
        ylabel('Start Time Rate Estimate (msec/sec)')
        xlim([0 Tfull])

    end

end
toc

fprintf('---------------------------------\n')
