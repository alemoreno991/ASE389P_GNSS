function arr_info(arr)

disp([min(arr) max(arr)])
disp([arr(1)   arr(end)])

end