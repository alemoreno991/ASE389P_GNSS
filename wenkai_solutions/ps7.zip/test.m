%% 4 fun
clear, clc

ecefGiven = [-738641.6553  -5462720.0395  3197898.1150
             -741133.4180  -5456322.9775  3208395.3863
             -740312.5579  -5457063.2879  3207249.7207
             -741991.1305  -5462229.1655  3198021.3786
             1101968.2340  -4583484.2540  4282240.1430
             6378137.0000         0.0           0.0];

llaGiven = ecef2lla(ecefGiven);

%% Estimate.
% Parameters.
MAX_ITER = 5;
CONV_LIM = 1e-7;

% Get pseudoranges.
tR = [429615.504253994
      429615.504514099
      429615.505066282
      429615.505190982];
tS = [429615.436
      429615.446
      429615.440
      429615.438];

c = 299792458; % speed of light, m/s
pseudor = c*(tR-tS);

rSvECEF = nan(4,3);
dtIono  = nan(4,1);
dtTropo = nan(4,1);
dtS     = nan(4,1);

% Data for PRN 14:
rSvECEF(1,:) = [-15206930.706156    -20832520.6664809      -6469517.7047024];
dtIono (1)   =  2.33838930420718e-08;
dtTropo(1)   =  1.90304034510942e-08;
dtS    (1)   =  0.000116168688750703;

% Data for PRN 21:
rSvECEF(2,:) = [ 644129.213511344    -22105331.2073303      14614081.7413721];
dtIono (2)   =  1.07933295823888e-08;
dtTropo(2)   =  8.36092156790743e-09;
dtS    (2)   = -0.000109838783947257;

% Data for PRN 22:
rSvECEF(3,:) = [-18139647.3560073    -12028727.5758169     15453336.7251709];
dtIono (3)   =  1.69238352966293e-08;
dtTropo(3)   =  1.31971700978366e-08;
dtS    (3)   =  0.000156846547048633;

% Data for PRN 27:
rSvECEF(4,:) = [ 17478991.6859777    -16545561.3989088      11624502.8670108];
dtIono (4)   =  1.71386691737267e-08;
dtTropo(4)   =  1.61167561114859e-08;
dtS    (4)   =  0.000217636932174885;

rRguess = ecefGiven(6,:); % Guess in ECEF
% rRguess = [0 0 0];

curr_conv = inf;
curr_estimate = Inf(4,1);

for iter = 1:MAX_ITER

    fprintf('---------------------------------\n')
    fprintf('Iteration %d.\n', iter)

    last_estimate = curr_estimate;
    pseudor = zZ

    % Construct H (measurement model).
    DR = rRguess-rSvECEF;
    normDR = sqrt(sum(DR.^2, 2));
    unitDR = diag(1./normDR) * DR;
    
    if unique(sqrt(sum(unitDR.^2, 2))) ~= 1
        error('norm bad');
    end
    
    H = [unitDR ones(4,1)];
    
    % Construct constant bias vector.
    bias = c*(-dtS+dtIono+dtTropo) - unitDR*rRguess' + normDR;

    % Estimate, and apply c scale factor to dtR.
    curr_estimate = (H'*H)\H'*(pseudor-bias);
    curr_estimate(4) = 1/c*curr_estimate(4);

    % Get convergence.
    curr_conv = norm(curr_estimate(4)-last_estimate(4));

    % Display and plot results.
    resultECEF = curr_estimate(1:3);
    resultLLA  = ecef2lla(resultECEF');
    fprintf('Lat = %6g, Lon = %6g, Alt = %6g Er\n', resultLLA(1:2), resultLLA(3)/6378.1e3)
    fprintf('dtS = %6g s\n', curr_estimate(4))
    fprintf('Convergence factor = %6g\n', curr_conv)

    figure(1)
    geoplot(resultLLA(1), resultLLA(2), '.');

    if curr_conv < CONV_LIM
        fprintf('Convergence limit reached.\n')
        break
    end

    if iter == MAX_ITER && curr_conv > CONV_LIM
        fprintf('Iteration limit reached without convergence.\n')
    end

end

fprintf('---------------------------------\n')

%% Try to calculate deltR.
format long g
dtS = 1/c*(pseudor + c*dtS - c*dtIono - c*dtTropo - normDR);
