Bn = 10; % Hz

% First order.
K = 4*Bn;
H1 = tf(K, [1 K]);

% Second order.
K = 8/3*Bn;
a = K/2;
H2 = tf([K K*a], [1 K K*a]);

% Third order.
a = 1.2*Bn;
b = a^2/2;
K = 2*a;
H3 = tf([K K*a K*b], [1 K K*a K*b]);

H = [H1; H2; H3];
figure(1), clf
hold on
hfig = bodeplot(H1);
setoptions(hfig,'FreqUnits','Hz')
hfig = bodeplot(H2);
setoptions(hfig,'FreqUnits','Hz')
hfig = bodeplot(H3);
setoptions(hfig,'FreqUnits','Hz')
grid on
legend('First Order','Second Order','Third Order')
% setoptions(hfig,'FreqUnits','Hz','PhaseVisible','off')

% Simulate.
t = linspace(0,3,1000);
u1 = min(1, floor(t));
u2 = max(0, t-1);
u3 = 0.5*max(0, (t-1).^2);
u3(t<=1) = 0;

figure(2), clf
subplot(131)
lsim(H, u1, t);
y1 = lsim(H, u1, t);
title('Step Response')
grid on

subplot(132)
lsim(H, u2, t);
y2 = lsim(H, u2, t);
title('Ramp Response')
grid on

subplot(133)
lsim(H, u3, t);
y3 = lsim(H, u3, t);
title('Quad. Response')
grid on

figure(3), clf
subplot(131)
hold on, grid on
xlabel('Time (sec)')
ylabel('Error')
title('Error in Response to Step Input')
plot(t, u1 - y1');

subplot(132)
hold on, grid on
xlabel('Time (sec)')
ylabel('Error')
title('Error in Response to Ramp Input')
plot(t, u2 - y2');

subplot(133)
hold on, grid on
xlabel('Time (sec)')
ylabel('Error')
title('Error in Response to Quad Input')
plot(t, u3 - y3');
legend('H1','H2','H3')