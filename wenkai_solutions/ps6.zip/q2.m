%% Simulate.
rho =     4; % signal amplitude, unitless
f   =   202; % frequency, Hz
th  =   0.5; % phase offset, rad
N   =   100; % number of accumulatinos, unitless
k   = 0:N-1; % accumulation indices, unitless
Ta  =  2e-3; % accumulation time, sec
nA  =     0; % noise amplitude, unitless

% Sk = ρ exp[i(2πfkTa+θ)]+nk
nk = nA*(randn(1,N) + 1j*randn(1,N));
Sk = rho * exp(1j * (2*pi*f*k*Ta + th) ) + nk;

X = real(Sk);
Y = imag(Sk);
Z = X + 1j*Y;

%% Estimate.
nfft = 2^(nextpow2(length(Z))+8);
% nfft = length(Z);
% nfft = 500;
A  = 1/N*fft(Z, nfft);
Af = (0:nfft-1)/(Ta*N)*N/nfft;

ind_max = find(abs(A) == max(abs(A)), 1);

f_est   =      Af(ind_max);
rho_est = abs  (A(ind_max));
th_est  = angle(A(ind_max));

%% Plot.
figure(1), clf
subplot(311)
hold on, grid on
plot(k*Ta, X)
plot(k*Ta, Y)
xlabel('Time (s)')
ylabel('Z')
legend('Re\{Z\}','Im\{Z\}')
title('Zk Time History')

subplot(312)
hold on, grid on
% plot(fftshift(Af), fftshift(abs(A)))
plot(Af, abs(A))
xlabel('Frequency (Hz)')
ylabel('|A(ω)|')
title('DFT of Zk')

subplot(313)
hold on, grid on
% plot(fftshift(Af), fftshift(abs(A)))
plot(Af, angle(A))
xlabel('Frequency (Hz)')
ylabel('∠[A(ω)]')
title('DFT of Zk')

%% Print results.
fprintf('  |  True  |   Est  |\n')
fprintf('---------------------\n')
fprintf('f | %6.3g | %6.3g | Hz\n'      , f  , f_est  )
fprintf('ρ | %6.3g | %6.3g | unitless\n', rho, rho_est)
fprintf('θ | %6.3g | %6.3g | rad\n'     , th , th_est )
