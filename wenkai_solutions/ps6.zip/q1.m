%% Simulate.
th  = 0;
rho = 4;

r = randn(2, 1e6);
q = r(1,:) + rho*sin(th);
i = r(2,:) + rho*cos(th);

thML = atan(q./i);

%% Get theoretical distribution.
w = linspace(-pi/2, pi/2, 100);
tanw = tan(w);
a = sqrt(tanw.^2+1);
b = rho*tanw*sin(th) + rho*cos(th);
c = rho^2;
d = exp((b.^2-c*a.^2)./(2*a.^2));

syms u
phi(u) = 1/sqrt(2*pi)*exp(-1/2*u^2);

Phi1 = normcdf( b./a);
Phi2 = normcdf(-b./a);

fqi = (b.*d)./(sqrt(2*pi)*a.^3) .* (Phi1-Phi2) + 1./(pi*a.^2).*exp(-c/2);
fthML = fqi./cos(w).^2;

%% Plot.
figure(1), clf
hold on, grid on
histogram(thML, 'Normalization', 'pdf', 'EdgeAlpha', 0.2)
plot(w, fthML)
xlim(pi/2*[-1 1])

xlabel('$^q/_i$', 'Interpreter', 'latex')
ylabel('$f_{\hat{\theta}_{ML}}(^q/_i)$', 'Interpreter', 'latex')
title('Theoretical vs. Experimental PDF')
legend('Experimental', 'Theoretical')