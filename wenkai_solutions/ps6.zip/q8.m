%% Setup.
% Simulation parameters.
Tinc   =   1.7e-6; % signal time resolution, sec
taujv  = 0:Tinc:.5; % simulated signal time, sec
Ta     =     1e-3; % accumulation time, sec
Aj     =        1; % signal amplitude, sqrt(W)
fIF    =    2.5e3; % intermediate frequency, Hz
CN0    =       35; % carrier-to-noise ratio, dB
method =   'ramp'; % phase offset generation method
th_0   =        0; % phase offset initial value

% Loop filter parameters.
Bn    = 10; % target bandwidth for filter design
order =  3; % loop filter design order

% Oversample data bits switching at 20 ms.
Dj = 2*randi([0 1],1,length(taujv))-1;
Dj = oversampleSpreadingCode(Dj, Tinc/20e-3, 0, length(taujv), length(Dj));

% Make phase shift vector.
pad_l  = round(.4/Tinc);
switch method
    case 'quad'
        th_tru = pi*taujv.^2;
    case 'ramp'
        slope  = 2*pi;
        th_tru = [slope*taujv(1:pad_l).*ones(1,pad_l), slope*taujv(pad_l)*ones(1, length(taujv)-pad_l)];
    case 'step'
        th_tru = [                     zeros(1,pad_l),                  5*ones(1, length(taujv)-pad_l)];
end
th_tru = th_tru + th_0;

% Create simulated signal.
linCN0 = 10^(CN0/10);                                    % linear C/N0
app_Nk = Ta/Tinc;                                        % approximate Nk
varIQ  = (app_Nk*mean(Aj)/2)^2/(2*linCN0*Ta);            % variance of accumulated noise
varn   = 2*varIQ/app_Nk;                                 % variance of independent noise samples
nj     = sqrt(varn)*randn(size(taujv));                  % noise, sqrt(W)
x      = Aj .* Dj' .* cos(2*pi*fIF*taujv + th_tru) + nj; % signal, sqrt(W)

% Design and set loop filter.
[Ad, Bd, Cd, Dd, Bn_act] = configureLoopFilter(Bn, Ta, order);
s.Ad = Ad;
s.Bd = Bd;
s.Cd = Cd;
s.Dd = Dd;

% Initialize loop state.
vk         =                  0; % estimated phase rate, rad
th_est     = zeros(size(taujv)); % estimated phase time history, rad
curr_accum =                  0; % number of accumulations already looped
Nk         =                  0; % number of samples in current accumulation
Sk_i       =                  0; % signal accumulator state
Sk_f       =                  0; % dumped integrator state
xkp1       =   zeros(order-1,1); % loop filter state.

% Loop through each time index. Average signal over subintervals of Ta.
Sk_rec = nan(1, round(taujv(end)/Ta));
vk_rec = nan(size(Sk_rec));
for j = 1:length(taujv)

    tauj = taujv(j);

    if floor(tauj/Ta) > curr_accum
        
        % Dump integral.
        Sk_f = Sk_i;
        s.Ip = real(Sk_f);
        s.Qp = imag(Sk_f);
        s.xk = xkp1;
        [xkp1,vk] = updatePll(s);
        
        % Reset/increment counters.
        curr_accum = curr_accum+1;
        Sk_i = 0;
        Nk = 0;
        Sk_rec(curr_accum) = Sk_f;

    end
 
    % Construct local replica.
    locrepl_j = exp(-1j*(2*pi*fIF*tauj+th_est(j)));

    % Increment accumulator.
    Sk_i = Sk_i + x(j)*locrepl_j;
    Nk = Nk+1;

    % Record the currently estimated phase offset.
    th_est(j+1) = th_est(j) + vk*Tinc;
    vk_rec(j) = vk;

end
Sk_rec(isnan(Sk_rec)) = [];

% Trim off last propagated value of estimated phase for plotting.
th_est(end) = [];

%% Plot.
figure(1), clf
subplot(211)
hold on, grid on
plot(taujv, x)
xlim([0 1/fIF])
xlabel('Time (s)')
ylabel('Amplitude')
title('Signal (One Period)')

subplot(212)
hold on, grid on
plot(taujv, th_tru)
plot(taujv, th_est,'--')
plot(taujv, th_est-th_tru)
xlabel('Time (s)')
ylabel('Phase (rad)')
legend('True','Estimated','Error','Location','northwest')
title('Phase Tracking Results')

ESk2 = mean(abs(Sk_rec).^2);
varIQ_exp = ESk2/(2*(linCN0*Ta+1));