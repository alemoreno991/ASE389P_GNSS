function [Ad,Bd,Cd,Dd,Bn_act] = configureLoopFilter(Bn_target,Ta,loopOrder)

% configureLoopFilter : Configure a discrete-time loop filter for a feedback % tracking loop.
%
%
% INPUTS
%
% Bn_target ----- Target loop noise bandwidth of the closed-loop system, in
%                 Hz.
%
% Ta ------------ Accumulation interval, in seconds. This is also the loop 
%                 update (discretization) interval.
%
% loopOrder ----- The order of the closed-loop system. Possible choices
%                 are 1, 2, or 3.
%
%
% OUTPUTS
%
% Ad,Bd,Cd,Dd --- Discrete-time state-space model of the loop filter.
%
% Bn_act -------- The actual loop noise bandwidth (in Hz) of the closed-loop
%                 tracking loop as determined by taking into account the
%                 discretized loop filter, the implicit integration of the
%                 carrier phase estimate, and the length of the accumulation
%                 interval.
%
%+------------------------------------------------------------------------------+
% References:
%
%
%+==============================================================================+

Bn = Bn_target;

% First order.
if loopOrder == 1
    K = 4*Bn;
    Ds = tf(K, 1);

% Second order.
elseif loopOrder == 2
    K = 8/3*Bn;
    a = K/2;
    Ds = tf([K K*a], [1 0]);

% Third order.
elseif loopOrder == 3
    a = 1.2*Bn;
    b = a^2/2;
    K = 2*a;
    Ds = tf([K K*a K*b], [1 0 0]);
    
else
    error('Error: Loop order not in range of [1,3].')
end

Dz = c2d(Ds, Ta, 'zoh');
NCOd = tf(Ta, [1 -1], Ta);
A = tf([1 1], [2 0], Ta);

sys_OL = A*Dz*NCOd;
sys_CL = feedback(sys_OL, 1);

Bn_act = calc_loopnoisebw(sys_CL, Ta);

% Convert to state space. 
[Ad,Bd,Cd,Dd] = ssdata(Dz);

end