%% Create all D.
Bn = 10; % Hz

% First order.
K = 4*Bn;
D1c = tf(K, 1);

% Second order.
K = 8/3*Bn;
a = K/2;
D2c = tf([K K*a], [1 0]);

% Third order.
a = 1.2*Bn;
b = a^2/2;
K = 2*a;
D3c = tf([K K*a K*b], [1 0 0]);

Dc = [D1c; D2c; D3c];

figi = 1;
for T = [1 10 20 40]*1e-3
% for T = 1*1e-3
    sim_discrete(Dc, T, figi, 'tustin');
    figi = figi+1;
end

%% Helpers.
function [y1, y2] = sim_discrete(Dc, T, fignum, method)

if nargin < 3
    fignum = 1;
end
if nargin < 4
    method = 'tustin';
end

NCOc = tf(1,[1 0]);

Dd = c2d(Dc, T, method);
D1d  = Dd(1);
D2d  = Dd(2);
D3d  = Dd(3);
NCOd = c2d(NCOc, T, method);

A = tf([1 1], [2 0], T);

fwd = A*D1d*NCOd;
H1  = feedback(fwd, 1);

fwd = A*D2d*NCOd;
H2  = feedback(fwd, 1);

fwd = A*D3d*NCOd;
H3  = feedback(fwd, 1);

H = [H1; H2; H3];

Bn_act = nan(3,1);
for order = 1:3
    Bn_act(order) = calc_loopnoisebw(H(order), T);
end
fprintf('Actual loop noise bandwidth for T = %2g ms: %5.4g %5.4g %5.4g\n', T*1e3, Bn_act)

% Simulate.
t = 0:T:3;
u1 = min(1, floor(t));
u2 = max(0, t-1);

figure(fignum), clf
alltitle = sprintf('T = %g ms Results', T * 1e3);
sgtitle(alltitle)

subplot(121)
lsim(H, u1, t);
y1 = lsim(H, u1, t);
title('Step Response')
grid on

subplot(122)
lsim(H, u2, t);
y2 = lsim(H, u2, t);
title('Ramp Response')
grid on

end
